package com.islamic.history

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.text.Editable
import android.text.TextWatcher

class MainActivity : Activity() {
    private val gold = Color.rgb(218, 178, 91)
    private val bg = Color.rgb(13, 13, 15)
    private val panel = Color.rgb(29, 28, 30)
    private var english = false
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var search: EditText

    data class Section(val ar: String, val en: String, val descAr: String, val descEn: String, val bodyAr: String, val bodyEn: String)

    private val sections = listOf(
        Section("السيرة النبوية", "Prophetic Biography", "حياة النبي محمد ﷺ وأحداث السيرة", "Life of Prophet Muhammad and events of the Seerah",
            "يعرض هذا القسم السيرة النبوية في وحدات زمنية: مكة قبل البعثة، بداية الوحي، الدعوة في مكة، الهجرة إلى المدينة، بناء المجتمع، وأهم أحداث العهد المدني. ستضاف المقالات الموسعة مع توثيق مصادرها في الإصدارات القادمة.",
            "This section presents the Prophetic biography in chronological units: early Mecca, the first revelation, the Makkan period, migration to Madinah, the formation of the community, and major events in Madinah. Expanded, sourced articles will be added in future releases."),
        Section("الخلفاء الراشدون", "The Rightly Guided Caliphs", "أبو بكر وعمر وعثمان وعلي رضي الله عنهم", "Abu Bakr, Umar, Uthman and Ali",
            "يتناول القسم عصر الخلافة الراشدة، وترتيب الخلفاء، وأبرز الأحداث الإدارية والسياسية والعلمية. ينبغي قراءة الروايات التاريخية بمقارنة المصادر المعتمدة وعدم الجزم بما اختلف فيه المؤرخون.",
            "This section covers the Rashidun period, the order of the caliphs, and major administrative, political and scholarly developments. Historical reports should be compared across reliable sources, especially where historians differ."),
        Section("الصحابة والصحابيات", "Companions", "سير الصحابة والصحابيات ومواقفهم", "Biographies and contributions of the Companions",
            "سيضم هذا القسم تراجم الصحابة والصحابيات، مع التعريف بأسمائهم وأدوارهم وأبرز المواقف المنقولة عنهم. تُذكر الروايات مع مصادرها ودرجاتها عند توفر ذلك.",
            "This section will contain biographies of male and female Companions, their roles and notable reported accounts. Reports should be accompanied by source references and grading where available."),
        Section("التابعون وتابعو التابعين", "Followers and Successors", "أعلام الجيلين ومراكز العلم", "Notable figures and centers of learning",
            "يعرض تراجم التابعين وتابعي التابعين، وصلتهم بالصحابة، ومراكز العلم والرواية في مكة والمدينة والكوفة والبصرة والشام وغيرها.",
            "This section introduces the Tabi'un and the generation after them, their links to the Companions, and centers of scholarship and transmission in Makkah, Madinah, Kufa, Basra, Syria and elsewhere."),
        Section("الدول والممالك الإسلامية", "Islamic States and Dynasties", "الدول والسلالات والحكام عبر التاريخ", "States, dynasties and rulers through history",
            "فهرس زمني مبدئي: الخلافة الراشدة، الدولة الأموية، الدولة العباسية، الدول المستقلة والإقليمية، الدولة الفاطمية، السلاجقة، الأيوبيون، المماليك، الدولة العثمانية، ودول إسلامية أخرى. هذا الفهرس ليس حكماً بأن جميع هذه الدول متتابعة دون تداخل.",
            "Initial chronological index: Rashidun Caliphate, Umayyad Caliphate, Abbasid Caliphate, regional and independent dynasties, Fatimid Caliphate, Seljuks, Ayyubids, Mamluks, Ottoman Empire and other Muslim polities. These states did not all succeed one another in a simple, uninterrupted sequence."),
        Section("الفتوحات والمعارك", "Conquests and Battles", "السياق التاريخي والقادة والنتائج", "Historical context, leaders and outcomes",
            "يتناول القسم سياقات التوسع والتحولات السياسية والعسكرية، مع عرض اختلاف الروايات حول التواريخ والأعداد والنتائج. الغرض تعليمي تاريخي، مع تجنب اختزال الأحداث المعقدة في رواية واحدة.",
            "This section examines the context of territorial expansion and political-military change, noting where accounts differ on dates, numbers and outcomes. Its purpose is historical education rather than reducing complex events to a single narrative."),
        Section("العلماء والأئمة", "Scholars and Imams", "السير والمذاهب والمؤلفات", "Biographies, schools and works",
            "يضم تراجم العلماء والمحدثين والفقهاء والمؤرخين، مع ذكر شيوخهم وتلاميذهم وأهم مؤلفاتهم ومجالات أثرهم العلمي.",
            "This section will include biographies of scholars, hadith specialists, jurists and historians, with their teachers, students, major works and scholarly contributions."),
        Section("الخرائط والخط الزمني", "Maps and Timeline", "تصور جغرافي وتسلسل للأحداث", "Geographic context and chronological events",
            "ستضاف خرائط تاريخية وخطوط زمنية موثقة. الخرائط في هذه النسخة الأولية غير مرفقة بعد، ويلزم إدراج خرائط مرخصة ومراجعة حدودها وتواريخها قبل النشر.",
            "Sourced historical maps and timelines will be added. Maps are not included in this starter release; licensed maps and their dates and boundaries must be reviewed before publication.")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildHome()
    }

    private fun txt(s: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView {
        return TextView(this).apply {
            text = s; textSize = size; setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
            gravity = if (english) Gravity.LEFT else Gravity.RIGHT
            setPadding(4, 5, 4, 5)
        }
    }

    private fun buildHome(query: String = "") {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            layoutDirection = if (english) View.LAYOUT_DIRECTION_LTR else View.LAYOUT_DIRECTION_RTL
            setPadding(18, 18, 18, 12)
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = TextView(this).apply {
            text = if (english) "Islamic History\nEncyclopedia" else "موسوعة التاريخ الإسلامي"
            textSize = 23f; setTextColor(gold); setTypeface(null, Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val lang = Button(this).apply {
            text = if (english) "العربية" else "English"
            setTextColor(gold); setBackgroundColor(panel)
            setOnClickListener { english = !english; buildHome(searchText()) }
        }
        header.addView(title); header.addView(lang); root.addView(header)

        val subtitle = txt(if (english) "A growing offline historical reference" else "مرجع تاريخي متنامٍ يعمل دون إنترنت", 13f, Color.LTGRAY)
        root.addView(subtitle)

        search = EditText(this).apply {
            hint = if (english) "Search sections..." else "ابحث في الأقسام..."
            setHintTextColor(Color.GRAY); setTextColor(Color.WHITE); textSize = 16f
            setSingleLine(true); setPadding(14, 10, 14, 10)
            setBackgroundColor(panel)
            setText(query)
        }
        root.addView(search, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = 14; bottomMargin = 12 })

        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val footer = txt(if (english) "Starter edition • Offline content included in the app" else "النسخة التمهيدية • المحتوى المضمّن يعمل دون إنترنت", 11f, gold)
        footer.gravity = Gravity.CENTER
        root.addView(footer)
        setContentView(root)
        renderCards(query)

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { renderCards(s?.toString() ?: "") }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun searchText(): String = if (::search.isInitialized) search.text.toString() else ""

    private fun renderCards(query: String) {
        if (!::content.isInitialized) return
        content.removeAllViews()
        val q = query.trim().lowercase()
        val filtered = sections.filter {
            q.isEmpty() || listOf(it.ar, it.en, it.descAr, it.descEn).any { v -> v.lowercase().contains(q) }
        }
        filtered.forEach { section ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(16, 12, 16, 12)
                setBackgroundColor(panel)
                isClickable = true
                setOnClickListener { showArticle(section) }
            }
            card.addView(txt(if (english) section.en else section.ar, 18f, gold, true))
            card.addView(txt(if (english) section.descEn else section.descAr, 13f, Color.LTGRAY))
            content.addView(card, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 10 })
        }
        if (filtered.isEmpty()) {
            content.addView(txt(if (english) "No matching sections" else "لا توجد أقسام مطابقة", 15f, Color.LTGRAY))
        }
    }

    private fun showArticle(s: Section) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(20, 22, 20, 20); setBackgroundColor(bg)
            layoutDirection = if (english) View.LAYOUT_DIRECTION_LTR else View.LAYOUT_DIRECTION_RTL
        }
        val back = Button(this).apply {
            text = if (english) "← Back" else "رجوع"
            setTextColor(gold); setBackgroundColor(panel); setOnClickListener { buildHome(searchText()) }
        }
        box.addView(back)
        box.addView(txt(if (english) s.en else s.ar, 23f, gold, true))
        box.addView(txt(if (english) s.bodyEn else s.bodyAr, 16f))
        box.addView(txt(if (english) "Sources and references will be added article by article." else "ستضاف مصادر ومراجع موثقة لكل مقالة على حدة.", 13f, gold))
        setContentView(ScrollView(this).apply { addView(box) })
    }
}
